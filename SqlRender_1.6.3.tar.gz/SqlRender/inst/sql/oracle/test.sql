SELECT a FROM table;
